
export const adService = {};
