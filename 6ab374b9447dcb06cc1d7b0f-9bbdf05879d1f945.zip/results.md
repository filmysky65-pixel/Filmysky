# Contact Page Updates

The "Contact Us" page has been simplified to focus exclusively on community chat, removing the previous contact form and social media links. Additionally, the help popup button has been configured to automatically hide when viewing the contact page to prevent redundancy.

## Changes
- **Simplified Contact Page:** Removed the email contact form and social media list from the Contact Us page. The page now only displays the public chat interface.
- **Updated Help Popup:** Modified the floating help button to hide itself when the user is already on the Contact Us page (`/contact`), in addition to being hidden on the Home page.